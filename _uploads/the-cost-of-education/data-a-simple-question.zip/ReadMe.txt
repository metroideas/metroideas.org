{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red28\green28\blue28;}
\margl1440\margr1440\vieww13680\viewh9320\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 == METRO IDEAS PROJECT ==\
Data for Post 1 - A Simple Question\
Created - 03/11/16\
\
== INTRODUCTION ==\
This zip contains the cleaned data used to create the visualizations for Post 1 - A Simple Question. Additional data is included that was used to support the written analysis.\
\
== CONTENTS ==\
\
1. TN_GRAD_BY_COUNTY\
2. TITLE_I_SCHOOLS\
\
== DESCRIPTION ==\
\
1. TN_GRAD_BY_COUNTY\
\
Variables: ECONOMICALLY_DISADVANTAGED_PCT; AFRICAN_AMERICAN_PCT;  PER_PUPIL_EXPENDITURES_PER_ADA; WHITE_PCT; HISPANIC_PCT; ASIAN_PCT; LIMITED_ENGLISH_PROFICIENT_PCT\
Source: Tennessee Department of Education, Profile Data Files Updated 11/25/15, District-level for 2015.\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
\pard\pardeftab720
\cf2 \expnd0\expndtw0\kerning0
Variable: MEDIAN_INCOME_2014\
Source: U.S. Census Bureau 2014 American Community Survey 1-Year Estimate, table S1903. \
See: {\field{\*\fldinst{HYPERLINK "http://factfinder.census.gov/faces/tableservices/jsf/pages/productview.xhtml?src=bkmk"}}{\fldrslt http://factfinder.census.gov/faces/tableservices/jsf/pages/productview.xhtml?src=bkmk}}\
\
Variable: All_grad_rate\
Source: T\cf0 \kerning1\expnd0\expndtw0 ennessee Department of Education, Attendance and Graduation Files Updated 11/25/15, District-level (2015)\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
Variable: AVERAGE_DAILY_ATTENDANCE\
Source: \cf2 \expnd0\expndtw0\kerning0
T\cf0 \kerning1\expnd0\expndtw0 ennessee Department of Education, Annual Statistical Report\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/article/2015-annual-statistical-report"}}{\fldrslt https://www.tn.gov/education/article/2015-annual-statistical-report}}\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
2. TITLE_I_SCHOOLS \
\
Variable: TITLE_!\
Source: Hamilton County Department of Education (2015-16)\
0 = no\
1 = yes\
See: {\field{\*\fldinst{HYPERLINK "http://www.hcde.org/?PN=Pages&SubP=Level1Page&L=2&DivisionID=14285&DepartmentID=15178&PageID=20951&ToggleSideNav=ShowAll"}}{\fldrslt http://www.hcde.org/?PN=Pages&SubP=Level1Page&L=2&DivisionID=14285&DepartmentID=15178&PageID=20951&ToggleSideNav=ShowAll}}\
\
Variable: ECONOMICALLY_DISADVANTAGED_PCT\
Source: Tennessee Department of Education, Profile Data Files Updated 11/25/15, School-level (2015)\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
== CONTACT ==\
Please address questions to: info@metroideas.org}