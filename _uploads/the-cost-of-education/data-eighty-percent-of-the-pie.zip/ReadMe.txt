{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww14020\viewh11280\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 == METRO IDEAS PROJECT ==\
Data for Post 3 - Eighty Percent of the Pie\
Created - 03/18/16\
\
== INTRODUCTION ==\
This zip contains the cleaned data used to create the visualizations for Post 3 - Eighty Percent of the Pie. Additional data may also be included that was used to support the written analysis.\
\
== CONTENTS ==\
\
1. PER_PUPIL_AVG_SALARY_BENEFIT_2016\
2. PER_PUPIL_AVG_SALARY_2008_2016\
3. TEACHER_INVESTMENT_INDEX\
4. FY16_PERSCHOOL_SALARY_BENEFITS_ELEMENTARY\
5. FY16_PERSCHOOL_SALARY_BENEFITS_MIDDLE\
6. FY16_PERSCHOOL_SALARY_BENEFITS_HIGH\
\
== DESCRIPTION ==\
\
1. PER_PUPIL_AVG_SALARY_BENEFIT_2016\
\
Variables: \
SCHOOL: School name\
GRADES_SERVED: Grades served\
ADM: Average daily membership\
SALARY_BENEFITS: Combined salary and benefits for all school-level personnel\
AVGPERSTUDENT: SALARY_BENEFITS / ADM\
TITLE_I: 0 = no; 1 = yes\
DOLLAR_DIFF_AVG: School average - average for all schools (=$5,633.51)\
DOLLAR_DIFF_TITLEI_AVG: School average - average for all Title I schools (=$5,796.88)\
DOLLAR_DIFF_NONTITLEI_AVG: School average - average for all non-Title I schools (=$5,398.13)\
PER_DIFF_AVG: School average - average for all schools (=$5,633.51)\
PER_DIFF_TITLEI_AVG: School average - average for all Title I schools (=$5,796.88)\
PER_DIFF_NONTITLEI_AVG: School average - average for all non-Title I schools (=$5,398.13)\
\
Source: HCDE for 2016 data\
\
2. PER_PUPIL_AVG_SALARY_2008_2016\
\
Variables: \
SCHOOL: School name\
GROUP: Code for four groups\
DESCRIPTION: Indicates whether a school moved closer or farther away from the average and whether that movement was an increase or decrease in funds.\
SALARY_08: Salary for all school-level personnel for 2008\
ADM_08: Average daily membership for 2008\
PER_DIFF_AVG_08: School average - average for all schools for 2008 (=$3,316.36)\
SALARY_16: Salary for all school-level personnel for 2016\
ADM_16: Average daily membership for 2016\
PER_DIFF_AVG_16: School average - average for all schools for 2016 (=$4,099.55)\
\
Source: HCDE for 2016 data\
\
Source: \expnd0\expndtw0\kerning0
U.S. Department of Education, Office of Planning, Evaluation and Policy Development, Policy and Program Studies Service, Comparability of State and Local Expenditures Among Schools Within Districts: A Report From the Study of School-Level Expenditures, by Ruth Heuer and Stephanie Stullich, Washington, D.C., 2011.\kerning1\expnd0\expndtw0 \
See: {\field{\*\fldinst{HYPERLINK "http://www2.ed.gov/about/offices/list/opepd/ppss/reports.html#title"}}{\fldrslt http://www2.ed.gov/about/offices/list/opepd/ppss/reports.html#title}}\
\
3. TEACHER_INVESTMENT_INDEX\
\
Variables: \
SCHOOL: School name\
TITLE_I: 0 = no; 1 = yes\
INDEX_SCORE: \'93Teacher Investment Index\'94 score\
ADM: Average daily membership\
MINORITY: Percent non-white students\
LIMITED_ENGLISH_PROFICIENT_PCT: Percent limited English proficiency students\
ECONOMICALLY_DISADVANTAGED_PCT: Percent economically disadvantaged students\
TVAAS_COMPOSITE: School-wide composite TVAAS score\
TVAAS_LITERACY: School-wide composite TVAAS literacy score\
TAAVA_NUMERACY: School-wide composite TVAAS numeracy score\
TVAAS_LITERACY_NUMERACY: School-wide composite TVAAS literacy and numeracy score\
TVAAS_SCIENCE: School-wide composite TVAAS science score\
\
Source: HCDE for teacher qualification and years teaching\
Note: 2014/15 data\
\
Source: Tennessee Department of Education, Profile Data Files Updated 11/25/15, School-level for 2015\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
Source: Tennessee Department of Education, School Wide TVAAS, 2015\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
4. FY16_PERSCHOOL_SALARY_BENEFITS_ELEMENTARY\
5. FY16_PERSCHOOL_SALARY_BENEFITS_MIDDLE\
6. FY16_PERSCHOOL_SALARY_BENEFITS_HIGH\
\
Source: HCDE \
\
== CONTACT ==\
Please address questions to: info@metroideas.org}