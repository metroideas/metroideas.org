{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red28\green28\blue28;}
\margl1440\margr1440\vieww14000\viewh11640\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 == METRO IDEAS PROJECT ==\
Data for Post 2 - Follow the Money\
Created - 03/15/16\
\
== INTRODUCTION ==\
This zip contains the cleaned data used to create the visualizations for Post 2 - Follow the Money. Additional data is included that was used to support the written analysis.\
\
== CONTENTS ==\
\
1. TN_SCHOOL_FUNDING_SOURCES\
2. HCDE_REVENUE_ENROLLMENT\
3. COMMISSION_DISCRETIONARY_FUNDS\
\
== DESCRIPTION ==\
\
1. TN_SCHOOL_FUNDING_SOURCES\
\
Variables: \
LOCAL: Revenue from local sources\
PER_LOCAL: Percent of local revenue out of total revenue\
STATE: Revenue from state sources\
PER_STATE: Percent of state revenue out of total revenue\
FEDERAL: Revenue from federal sources\
PER_FEDERAL: Percent of federal revenue out of total revenue\
TOTAL: LOCAL+STATE+FEDERAL\
FED_TITLE_I: Revenue from Title I grant\
PER_FED_TITLE_I: (FED_TITLE_I)/(TOTAL)\
FED_IDEA: Revenue from IDEA grant\
PER_FED_IDEA: (FED_IDEA)/(TOTAL)\
FED_REST: FEDERAL - FED_TITLE_I - FED_IDEA\
PER_FED_REST: (FED_REST)/(TOTAL)\
Source: \cf2 \expnd0\expndtw0\kerning0
Tennessee Department of Education's annual statistical report for the scholastic year ending June 30, 2015, Table 19: Current Revenue\cf0 \kerning1\expnd0\expndtw0 \
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/assets/entities/education/attachments/asr_1314.pdf"}}{\fldrslt https://www.tn.gov/assets/entities/education/attachments/asr_1314.pdf}}\
\
2.  HCDE_REVENUE_ENROLLMENT\
\
Variables:\
CATEGORY: Includes \'93General purpose school, federal projects, self-funded projects\'94 and \'93Food service\'94 as well as \'93Average daily membership\'94 for student enrollment\
JURISDICTION: Includes \'93local\'94, \'93state\'94 and \'93federal\'94\
ITEM: Includes itemized revenue sources and number of pupils\
FY1998-FY2015: Revenue for FY 1998 to 2015\
Source: HCDE; Hamilton County Comprehensive Annual Financial Reports (CAFR)\
See: {\field{\*\fldinst{HYPERLINK "https://tn.gov/finance/article/fa-accfin-cafr"}}{\fldrslt http://www.hamiltontn.gov/CAFR/}}\
Note: All figures are nominal. To calculate inflation-adjusted see:\
{\field{\*\fldinst{HYPERLINK "http://data.bls.gov/pdq/SurveyOutputServlet?series_id=CUUR0300SA0,CUUS0300SA0"}}{\fldrslt http://data.bls.gov/pdq/SurveyOutputServlet?series_id=CUUR0300SA0,CUUS0300SA0}} for CPI, Southern Urban\
\
3. COMMISSION_DISCRETIONARY_FUNDS\
Variables:\
FY: Fiscal years 2014-16\
DISTRICT: Hamilton County district\
AMOUNT: Amount contributed to school\
SCHOOL: Recipient school(s)\
USE: Use of funds\
Source: http://www.hamiltontn.gov/Commission/DSReports/FY2016.pdf; {\field{\*\fldinst{HYPERLINK "http://www.hamiltontn.gov/Commission/DSReports/FY2015.pdf"}}{\fldrslt http://www.hamiltontn.gov/Commission/DSReports/FY2015.pdf}}; {\field{\*\fldinst{HYPERLINK "http://www.hamiltontn.gov/Commission/DSReports/FY2014.pdf"}}{\fldrslt http://www.hamiltontn.gov/Commission/DSReports/FY2014.pdf}}\
\
== CONTACT ==\
Please address questions to: info@metroideas.org}