{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red28\green28\blue28;}
\margl1440\margr1440\vieww13080\viewh13100\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 == METRO IDEAS PROJECT ==\
Data for Post 4 - One Answer, Many Questions\
Created - 04/11/16\
\
== INTRODUCTION ==\
This zip contains the cleaned data used to create the visualizations for Post 4 - One Answer, Many Questions. Additional data is included that was used to support the written analysis.\
\
== CONTENTS ==\
\
1. 10YEAR_SPENDING_US_TN_HAMILTON\
2. 2015_STATE_RANK_PERSTUDENT\
3. 2015_SCHOOL_ACCOUNTABILITY\
4. 2015_DISTRICT_ACCOUNTABILITY\
5. 2015_PERSTUDENT_RELATIVE_AVG\
6. 2015_SPENDING_ACHIEVEMENT\
\
== DESCRIPTION ==\
\
1. 10YEAR_SPENDING_US_TN_HAMILTON\
\
Variables: \
YEAR: fiscal year\
AVG_US: average per-pupil spend across the US by year\
AVG_TN: average per-pupil spend in Tennessee by year\
AVG_HAMILTON: average per-pupil in Hamilton County by year\
Source: For national and state data: National Education Association, Ranking of States and Estimates of School Statistics, 2004/05-2014/15, Summary Table J & K. Estimated Expenditures for Public Schools; For Hamilton County data: Hamilton County CAFR\cf2 \expnd0\expndtw0\kerning0
\
\cf0 \kerning1\expnd0\expndtw0 See: http://www.nea.org/home/44479.htm; {\field{\*\fldinst{HYPERLINK "http://www.hamiltontn.gov/CAFR/"}}{\fldrslt http://www.hamiltontn.gov/CAFR/}}\
\
\
2. 2015_STATE_RANK_PERSTUDENT\
\
Variables:\
STATE: state\
AMOUNT: total spending amount\
ADA: average spending per average daily admission (ADA)\
ENR: average spending per enrollment\
Source: National Education Association, Ranking of States and Estimates of School Statistics, 2014/15, Summary Table K. Estimated Expenditures for Public Schools\
See: http://www.nea.org/home/44479.htm \
\
3. 2015_SCHOOL_ACCOUNTABILITY\
\
Variables:\
YEAR: year\
DISTRICT: Hamilton County district code\
SCHOOL: school code\
SCHOOL_NAME: school name\
SUBJECT: Math; RLA (reading/language arts); Algebra I; English II\
GRADE: 3rd; 7th; 9th-12th\
SUBGROUP: All students\
VALID_TESTS: number of valid tests\
PCT_BELOW_BSC: percent below basic\
PCT_BSC: percent basic\
PCT_BSC_AND_BELOW: percent basic and below\
PCT_PROF: percent proficient\
PCT_ADV: percent advanced\
PCT_PROF_ADV: percent proficient and advanced\
Source: Tennessee Department of Education, Aggregate Accountability, School-level 2015\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
4. 2015_DISTRICT_ACCOUNTABILITY\
\
Variables:\
YEAR: year\
DISTRICT: Hamilton County district code\
SUBJECT: Math; RLA (reading/language arts); Algebra I; English II\
GRADE: 3rd; 7th; 9th-12th\
SUBGROUP: All students\
VALID_TESTS: number of valid tests\
PCT_BELOW_BSC: percent below basic\
PCT_BSC: percent basic\
PCT_BSC_AND_BELOW: percent basic and below\
PCT_PROF: percent proficient\
PCT_ADV: percent advanced\
PCT_PROF_ADV: percent proficient and advanced\
Source: Tennessee Department of Education, Aggregate Accountability, School-level 2015\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
5. 2015_PERSTUDENT_RELATIVE_AVG\
\
Variables:\
RANGE: percent difference from average district per-student spending \
ELEMENTARY: percent of total elementary schools per range category\
MIDDLE: percent of total middle schools per range category\
HIGH: percent of total high schools per range category\
ALL: percent of total schools per range category\
\
6. 2015_SPENDING_ACHIEVEMENT\
Variables:\
NAME: name of school\
TITLE: Tile I school = 1; non-Title I = 0\
GRADE: grade served\
MATH_DIFF: difference between school and district average for percent proficient or advanced in Math\
ENGLISH_DIFF: difference between school and district average for percent proficient or advanced in English\
MATH: accountability score for percent proficient or advanced in Math\
ENGLISH: accountability score for percent proficient or advanced in English\
AVERAGE: average per-student spending\
Source: Tennessee Department of Education, Aggregate Accountability, School-level 2015; District-level 2015\
See: {\field{\*\fldinst{HYPERLINK "https://www.tn.gov/education/topic/data-downloads"}}{\fldrslt https://www.tn.gov/education/topic/data-downloads}}\
\
== CONTACT ==\
Please address questions to: info@metroideas.org}